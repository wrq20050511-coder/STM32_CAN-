#ifndef CAN_BUS_H
#define CAN_BUS_H

#include <stdint.h>
#include "can_io.h"

#define CAN_BUS_MAIN       1U
#define CAN_BUS_KEYBOARD   3U
#define CAN_BUS_MONITOR    4U
#define CAN_BUS_SIGNAL_BOX 31U

typedef struct
{
    uint8_t index;
    uint8_t src_id;
    uint8_t src_type;
    uint8_t dst_id;
    uint8_t dst_type;
    uint8_t filt_src;
    uint8_t filt_dst;
} CanBusConfig;

struct CanBusNode;
struct CanBusAdapter;

typedef struct CanBusNode
{
    uint32_t mask_id;
    uint32_t mask;
    uint32_t send_id;
    CanComDriver dev;
    struct CanBusAdapter *adapter;
    struct CanBusNode *next;
} CanBusNode;

typedef struct CanBusAdapter
{
    int (*send_msg)(uint32_t ext_id, const uint8_t *data, uint8_t len);
    int (*add_filter)(int filter_number, uint32_t internal_id, uint32_t mask);
    int filter_count;
    CanBusNode *first_node;
} CanBusAdapter;

CanBusAdapter *CanBus_Init(void);
int CanBus_RegisterDefaultNode(uint8_t local_id);
CanComDriver *CanBus_DefaultDevice(void);

int CanBus_Reset(CanBusAdapter *adapter);
int CanBus_ResetNode(CanBusNode *node);
int CanBus_InitAdapter(CanBusAdapter *adapter);
int CanBus_AddNode(CanBusAdapter *adapter, CanBusNode *node);
int CanBus_SetNodeByConfig(CanBusNode *node, const CanBusConfig *config);
int CanBus_HandleFrame(CanBusAdapter *adapter, uint32_t ext_id,
                       uint8_t *data, uint8_t len);

#endif
