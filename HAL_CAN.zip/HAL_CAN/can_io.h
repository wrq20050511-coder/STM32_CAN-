#ifndef CAN_IO_H
#define CAN_IO_H

#include <stdint.h>
#include "can_fifo.h"

struct CanComDriver;
typedef struct CanComDriver CanComDriver;

struct CanComDriver
{
    void *userData;
    void *parent;
    CanFifo *fifo;
    int (*single)(CanComDriver *self, uint8_t *data, int len);
    int (*write)(CanComDriver *self, uint8_t *data, int len);
};

int CanIo_Write(CanComDriver *dev, uint8_t *data, int len);
int CanIo_Dispatch(CanComDriver *dev, uint8_t *data, int len);

#endif
