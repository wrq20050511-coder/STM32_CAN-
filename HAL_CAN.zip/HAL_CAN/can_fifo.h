#ifndef CAN_FIFO_H
#define CAN_FIFO_H

#include <stdint.h>

typedef struct
{
    uint8_t *buf;
    uint32_t size;
    uint32_t in;
    uint32_t out;
} CanFifo;

int CanFifo_Init(CanFifo *fifo, uint8_t *buf, uint32_t size);
uint32_t CanFifo_Read(CanFifo *fifo, uint8_t *buf, uint32_t len);
uint32_t CanFifo_Write(CanFifo *fifo, const uint8_t *buf, uint32_t len);

#endif
