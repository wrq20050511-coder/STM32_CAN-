#ifndef CAN_PROTOCOL_H
#define CAN_PROTOCOL_H

#include <stdint.h>
#include "can_io.h"

typedef uint32_t (*CanProtocol_GetTime)(void);
typedef void (*CanProtocol_FrameCallback)(void *context);

typedef struct
{
    void *userData;
    void *parent;
    uint8_t saveFlag;
    uint8_t startc;
    uint8_t endc;
    uint32_t maxlen;
    uint32_t dataLen;
    uint32_t saveNum;
    uint8_t *data;
    uint32_t oldTime;
    uint32_t waitTimeMs;
    CanComDriver *dev;
    CanProtocol_FrameCallback completeCallback;
    CanProtocol_GetTime getTime;
} CanProtocolContext;

void CanProtocol_Init(CanProtocolContext *context, uint8_t *data, uint32_t len,
                      uint8_t startc, uint8_t endc, uint32_t wait_time_ms,
                      CanProtocol_GetTime get_time);
int CanProtocol_Bind(CanProtocolContext *context, CanComDriver *driver);
int CanProtocol_Input(CanProtocolContext *context, uint8_t value);
int CanProtocol_InputData(CanProtocolContext *context, uint8_t *data, int len);
int CanProtocol_Send(CanProtocolContext *context, uint8_t cmd,
                     const uint8_t *data, uint32_t len);
int CanProtocol_Wait(CanProtocolContext *context, uint8_t cmd, uint32_t timeout_ms);
int CanProtocol_Run(CanProtocolContext *context, uint8_t cmd,
                    const uint8_t *data, uint32_t len, uint32_t timeout_ms);
int CanProtocol_ExtractOffsetData(const CanProtocolContext *context, uint8_t *data);

#endif
