﻿#include "can_port.h"
#include "can.h"

#define CAN_ENABLE_RX_NOTIFICATION 1U

/**
 * @brief  初始化 CAN 硬件硬件外设与硬件接收滤波器
 * @return 0: 成功, <0: 对应阶段失败错误码
 */
int CanPort_Init(void)
{
    CAN_FilterTypeDef filter = {0};

    /* 配置硬件接收滤波器 Bank 0 */
    filter.FilterBank = 0U;
    filter.FilterMode = CAN_FILTERMODE_IDMASK;  // 标识符掩码模式
    filter.FilterScale = CAN_FILTERSCALE_32BIT;  // 32 位位宽
    filter.FilterIdHigh = 0U;
    filter.FilterIdLow = 4U;                     // 设置 IDE/RTR 匹配标记位
    filter.FilterMaskIdHigh = 0U;
    filter.FilterMaskIdLow = 4U;                  // 仅匹配 IDE/RTR 位
    filter.FilterFIFOAssignment = CAN_FILTER_FIFO0; // 绑定至 FIFO0
    filter.FilterActivation = ENABLE;            // 激活该滤波器
    filter.SlaveStartFilterBank = 14U;           // 双 CAN 主从分配界限 (针对双 CAN 芯片)

    /* 配置硬件滤波器、启动 CAN 控制器并开启中断 */
    if (HAL_CAN_ConfigFilter(&hcan, &filter) != HAL_OK) return -1;
    if (HAL_CAN_Start(&hcan) != HAL_OK) return -2;
#if CAN_ENABLE_RX_NOTIFICATION
    if (HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) return -3;
#endif
    return 0;
}

/**
 * @brief  通过 CAN 总线发送指定扩展 ID 帧
 * @param  ext_id 29 位扩展帧标识符 (Extended ID)
 * @param  data   发送数据缓冲区
 * @param  len    数据长度 (0 ~ 8 字节)
 * @return 0: 成功, <0: 参数错误或发送邮箱满失败
 */
int CanPort_Send(uint32_t ext_id, const uint8_t *data, uint8_t len)
{
    CAN_TxHeaderTypeDef header = {0};
    uint32_t mailbox;
    uint8_t frame_data[8] = {0};

    if (data == 0 || len > 8U || ext_id > 0x1FFFFFFFU) return -1;

    header.ExtId = ext_id;
    header.IDE = CAN_ID_EXT;       // 扩展帧模式
    header.RTR = CAN_RTR_DATA;     // 数据帧
    header.DLC = len;              // 字节长度
    header.TransmitGlobalTime = DISABLE;

    /* 拷贝数据至本地发送临时数组 */
    for (uint8_t i = 0U; i < len; i++) frame_data[i] = data[i];

    return (HAL_CAN_AddTxMessage(&hcan, &header, frame_data, &mailbox) == HAL_OK) ? 0 : -2;
}

/**
 * @brief  添加软件/硬件滤波器接口预留 (当前采用全通通配符 + 软件路由匹配)
 */
int CanPort_AddFilter(int filter_number, uint32_t internal_id, uint32_t mask)
{
    /* 上电时已配置通配扩展帧滤网，更精确的过滤在软件分发层进行 */
    (void)internal_id;
    (void)mask;
    return (filter_number == 0) ? 0 : -1;
}
