#ifndef CAN_PORT_H
#define CAN_PORT_H

#include <stdint.h>

int CanPort_Init(void);
int CanPort_Send(uint32_t ext_id, const uint8_t *data, uint8_t len);
int CanPort_AddFilter(int filter_number, uint32_t internal_id, uint32_t mask);

#endif
